package day2;

public class JackOfAll {

	/**
	 * 
	 * @param s1
	 * @param s2
	 * @return
	 */
	public String generateUserName(String s1, String s2) {
		
		return null ; 
	}
	/**
	 * 
	 * @param s
	 * @return
	 */
	public StringBuilder reverseWords(String s) {
		StringBuilder sb = new StringBuilder();
		return null;
	
	}
	/**
	 * 
	 * @param ints
	 * @return
	 */
	public int[] reverseIntArray(int[] ints) {

		return ints ;
	
	}
	/**
	 * 
	 * @param n
	 * @return
	 */
	public int sumOfNumberFrom1ToN(int n) {

		return 0;

	}
	
	/**
	 * 
	 * @param isPrimeMemer
	 * @param price
	 * @return
	 */
	public int calculateShipping(boolean isPrimeMemer, double price) {
		return 0 ; 
	}

	/**
	 * 
	 * @param s
	 * @return
	 */
	public String makeFirstCharCapital(String s) {
		
		return null ; 
	}

	/**
	 * 
	 * @param sentence
	 * @return
	 */
	public String makeFirstCharEveyWordCapital(String sentence) {
		// TODO Auto-generated method stub
		return null;
	}	
	/**
	 * 
	 * @param s
	 * @return
	 */
	public int getNumberOutOfString(String s) {
		
		String num = ""; 
		// Character.isDigitChar(yourchar ) will check whether it's a number
		return 0;
	}

	/**
	 * 
	 * @param is
	 * @return
	 */
	public boolean checkIfFirstOrLastItemMoreThan5(int[] is) {
		// TODO Auto-generated method stub
		return true;
	}

	/**
	 * 
	 * @param is
	 * @return
	 */
	public boolean checkAllLongsAreMoreThan20(int[] is) {
		// TODO Auto-generated method stub
		return true;
	}

	/**
	 * 
	 * @param ints
	 * @return
	 */
	public int findMaxOfAllNumbers(int[] ints) {
		// TODO Auto-generated method stub
		return 0;
	}
	/**
	 * 
	 * @param is
	 * @param is2
	 * @return
	 */
	public int compareMaxOf2Arrays(int[] is, int[] is2) {
		// TODO Auto-generated method stub
		return 0;
	}
	/**
	 * 
	 * @param string
	 * @return
	 */
	public boolean checkStringContainsNumber(String string) {
		// TODO Auto-generated method stub  Character.isDigit again
		return true;
	}

	/**
	 * 
	 * @param strings
	 * @return
	 */
	public long getNumberOutOfStringArray(String[] strings) {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * 
	 * @param strings
	 * @return
	 */
	public int sumEachNumberContainedInsideStringArray(String[] strings) {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * 
	 * @param string
	 * @return
	 */
	public boolean checkIfBooleanWordExistsInString(String string) {
		// TODO Auto-generated method stub
		return false;
	}


	
	
	
}
