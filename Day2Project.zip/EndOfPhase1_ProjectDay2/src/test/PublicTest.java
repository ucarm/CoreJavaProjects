package test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.*;
import org.junit.jupiter.api.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.ValueSource;

import day2.JackOfAll;

@DisplayName("Day 2 Practice Project ")
public class PublicTest {

	JackOfAll jack;

	@BeforeAll
	public static void init() {
		// System.out.println("Test Has Started");

	}

	@BeforeEach
	public void setUp() {
		jack = new JackOfAll();
	}

	@DisplayName("Testing UserName generator")
	@Test
	public void testUserNameGeneration() {

		assertAll(() -> assertEquals("ajackson", jack.generateUserName("Adam", "Jackson"), "Wrong Username Generated"),
				() -> assertEquals("dmiller", jack.generateUserName("Diana", "Miller"), "Wrong Username Generated"));
	}

	@DisplayName("Testing Reverse Word")
	@Test
	public void testReverseWord() {
		assertAll(
				() -> assertEquals(new StringBuilder("madA").toString(), jack.reverseWords("Adam").toString(),
						"not reversed correctly"),
				() -> assertEquals(new StringBuilder("BBAA321").toString(), jack.reverseWords("123AABB").toString(),
						"not reversed correctly"));
	}

	@DisplayName("Testing Sum of Number from 1 to Given number")
	@Test
	public void testSumOfNumberFrom1ToN() {

		assertAll(() -> assertEquals(6, jack.sumOfNumberFrom1ToN(3), "Sum of the Numbers Wrong"),
				() -> assertEquals(325, jack.sumOfNumberFrom1ToN(25), "Sum of the Numbers Wrong"),
				() -> assertEquals(55, jack.sumOfNumberFrom1ToN(10), "Sum of the Numbers Wrong"));
	}

	@DisplayName("Calculate Shipping Test")
	@Test
	public void testCalculateShipping() {
		assertEquals(0, jack.calculateShipping(true, 100));
		assertEquals(0, jack.calculateShipping(true, 1));
		assertEquals(0, jack.calculateShipping(false, 36));
		assertEquals(5, jack.calculateShipping(false, 35));
		assertEquals(5, jack.calculateShipping(false, 1));

	}

	@DisplayName("Make First Letter Capital Test")
	@Test
	public void testMakeFirstLetterCapitalTheRestLowerCase() {
		assertEquals("Abcd", jack.makeFirstCharCapital("ABCD"));
		assertEquals("Abcde", jack.makeFirstCharCapital("abcdE"));
		assertEquals("Abcdefg", jack.makeFirstCharCapital("abCdEFG"));

	}

	@DisplayName("Make First Character Of Every Word Capital Test")
	@Test
	public void testMakeFirstLetterEveryWordCapitalCapitalTheRestLowerCase() {
		assertEquals("Abc Bs Vvd", jack.makeFirstCharEveyWordCapital("Abc bs vvd"));
		assertEquals("Ab Cd E", jack.makeFirstCharEveyWordCapital("ab cd E"));
		assertEquals("Ab Cd Ef Gd", jack.makeFirstCharEveyWordCapital("ab Cd EF Gd"));

	}

	@DisplayName("Get Number Out Of String Test")
	@Test
	public void testGetNumberOutOfString() {
		assertEquals(123, jack.getNumberOutOfString("abc1m23"));
		assertEquals(0, jack.getNumberOutOfString("abc"));
		assertEquals(1234, jack.getNumberOutOfString("1234"));
	}

	@DisplayName("Check int Array First Or Last Item more than 5")
	@Test
	public void testCheckIfArrayFirstOrLastItemMoreThan5() {
		assertTrue(jack.checkIfFirstOrLastItemMoreThan5(new int[] { 6, 3, 2, 3, 2, 6 }));
		assertFalse(jack.checkIfFirstOrLastItemMoreThan5(new int[] { 1, 2, 6 }));
		assertFalse(jack.checkIfFirstOrLastItemMoreThan5(new int[] { 6, 3, 1 }));

	}

	@DisplayName("Check All Longs Are More Than 20 test")
	@Test
	public void testCheckAllLongsAreMoreThan20() {
		assertFalse(jack.checkAllLongsAreMoreThan20(new int[] { 56, 13, 22, 113, 12, 6 }));
		assertTrue(jack.checkIfFirstOrLastItemMoreThan5(new int[] { 111, 2222, 622 }));
		assertFalse(jack.checkIfFirstOrLastItemMoreThan5(new int[] { 6, 3222, 1122333 }));
		assertTrue(jack.checkIfFirstOrLastItemMoreThan5(new int[] { 21 }));

	}

	@DisplayName("Find Max Of All Numbers test")
	@Test
	public void testFindMaxOfAllNumbers() {
		assertEquals(113, jack.findMaxOfAllNumbers(new int[] { 56, 13, 22, 113, 12, 6 }));
		assertEquals(2222, jack.findMaxOfAllNumbers(new int[] { 111, 2222, 622 }));
		assertEquals(1122333, jack.findMaxOfAllNumbers(new int[] { 6, 3222, 1122333 }));
		assertEquals(21, jack.findMaxOfAllNumbers(new int[] { 21 }));

	}

	@DisplayName("Compare Max Of 2 Arrays")
	@Test
	public void testCompareMaxOf2Arrays() {
		assertEquals(-1,
				jack.compareMaxOf2Arrays(new int[] { 56, 13, 22, 113, 12, 6 }, new int[] { 56, 12, 22, 1113, 12, 6 }));
		assertEquals(1, jack.compareMaxOf2Arrays(new int[] { 111, 2222, 622 }, new int[] { 2, 62 }));
		assertEquals(0, jack.compareMaxOf2Arrays(new int[] { 6, 11, 123 }, new int[] { 61, 111, 123 }));
		assertEquals(-1, jack.compareMaxOf2Arrays(new int[] { 21 }, new int[] { 22, 22 }));

	}

	@DisplayName("Check String Contains Number")
	@Test
	public void testCheckStringContainsNumber() {
		assertTrue(jack.checkStringContainsNumber("ABC123"), "This String does not contains number");
		assertFalse(jack.checkStringContainsNumber("ABC"), "This String does not contains number");
		assertTrue(jack.checkStringContainsNumber("123"), "This String does not contains number");

	}

	@DisplayName("Check String Array Contains Number")
	@Test
	public void testCheckStringArrayContainsNumber() {
		assertTrue(jack.checkStringContainsNumber("ABC123"), "This String does not contains number");
		assertFalse(jack.checkStringContainsNumber("ABC"), "This String does not contains number");
		assertTrue(jack.checkStringContainsNumber("123"), "This String does not contains number");

	}

	@DisplayName("Get Number Out of String Array Test")
	@Test
	public void testGetNumberOutOfStringArray() {
		assertEquals(1232, jack.getNumberOutOfStringArray(new String[] { "ABC123", "AC2" }));
		assertEquals(1232, jack.getNumberOutOfStringArray(new String[] { "ABC123", "AC2", "ACF" }));
		assertEquals(0, jack.getNumberOutOfStringArray(new String[] { "ABC", "AC", "ACF" }));

	}

	@DisplayName("Get Number Out of String Array Test Then get Sum Test")
	@Test
	public void testSumEachNumberContainedInsideStringArray() {
		assertEquals(223, jack.sumEachNumberContainedInsideStringArray(new String[] { "ABC123", "AC100" }));
		assertEquals(125, jack.sumEachNumberContainedInsideStringArray(new String[] { "ABC123", "AC2", "ACF" }));
		assertEquals(0, jack.sumEachNumberContainedInsideStringArray(new String[] { "ABC", "AC", "ACF" }));

	}

	@DisplayName("Check whether a boolean exists in String Test")
	@Test
	public void testCheckIfBooleanWordExistsInString() {
		assertTrue(jack.checkIfBooleanWordExistsInString("TrueStatementFalse"));
		assertFalse(jack.checkIfBooleanWordExistsInString("truStatemente"));
		assertFalse(jack.checkIfBooleanWordExistsInString("FalStatemente"));
		assertFalse(jack.checkIfBooleanWordExistsInString("ssss"));

	}

	@AfterEach
	public void tearDown() {
		jack = null;
	}

	@AfterAll
	public static void cleanUp() {
		System.out.println("End of The Test");
	}

}
