package draw;
import java.awt.Color;

import grid.Grid;

public class DrawFlag {
	
	public static void drawFlag(Grid grid, int countryCode) {

		switch(countryCode) {
			case 1:
				france(grid); 
				break;
			case 2:
				argentina(grid); 
				break;
				
			case 3:
				austria(grid); 
				break;
			case 4:
				ukraine(grid); 
				break;
			case 5:
				russia(grid); 
				break;
			case 6:
				mycountry(grid); 
				break;
			default: 
				ErrorFlag(grid); 
				break;
		}
	} 

	public static void ErrorFlag(Grid grid) {
		
		int height = grid.getHt();
		int width = grid.getWd();
		
		for(int col = 0; col < width; col++) {
			grid.setColor(0, col, Color.RED);
		}			
		
		for(int row = 0; row < height; row++) {
			grid.setColor(row, 0, Color.RED);
		}
		
		for(int col = 0; col < width; col++) {
			grid.setColor(height-1, col, Color.RED);
		}			
		
		for(int row = 0; row < height; row++) {
			grid.setColor(row, width-1, Color.RED);
		}
		
		
	}
	
	private static void france(Grid grid) {
		//TO DO
		//Draw France flag
		//Hint: grid.setColor(row, col, Color.RED); will change the color of 
		// one cell at (row,col) to red
		
		//Frace flag is three vertical stripes of blue, white and red
	}
	
	private static void argentina(Grid grid) {
		//TO DO
		//Draw the flag of Argentina
	}
	
	private static void austria(Grid grid) {
		//TO DO
		//Draw the flag of Austria
	}
	
	private static void ukraine(Grid grid) {
		//TO DO
		//Draw the flag of Ukraine
	}
	private static void russia(Grid grid) {
		//TO DO
		//Draw the flag of Russia
	}
	
	private static void mycountry(Grid grid) {
		//TO DO
		//Draw the flag of your own country
	}
}
